cask "locker" do
  version "7.8"
  sha256 "dca23ac984a7f6dff42f3f2629e6fe757aae53b52d53fb52380213db2b8aedca"

  url "https://cli.lockerlabs.io/brew/mac#{version.major}/Locker-CLI-#{version}.zip"
  name "Locker"
  desc "Password manager that keeps all passwords secure behind one password"
  homepage "https://1password.com/"

  livecheck do
    url "https://app-updates.agilebits.com/product_history/OPM#{version.major}"
    strategy :page_match
    regex(%r{href=.*?/1Password-(\d+(?:\.\d+)*)\.pkg}i)
  end

  auto_updates true

  app "Locker #{version.major}.app"

  zap trash: [
    "~/Library/Logs/Locker",
  ]
end

